new_company_values = {"ms_list": []}
