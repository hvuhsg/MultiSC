import logging


filename = r"server.log"

loggin_format = "%(levelname)s - %(asctime)s - %(threadName)s - %(name)s: %(message)s"

level = logging.DEBUG

catch_event_level = logging.ERROR
